first_name = input("Enter first name: ")
last_name = input("Enter last name: ")
age = int(input("Enter age: "))

for age in range (0, age):
    print(f"Happy Birthday, {first_name} {last_name}!")